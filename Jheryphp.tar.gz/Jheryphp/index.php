<?php
require 'users/users.php';

$users = getUsers();

include 'partials/header.php';
?>

<!-- Se añadió py-5 (padding vertical), Hace que el contenido respire más y se vea menos comprimido. -->
<div class="container py-5">

    <!-- Nuevo bloque - Encabezado con título y botón alineados
         flexbox (d-flex) para alinear título y botón.
         fw-bold: título más visible.
         shadow-sm: botón con ligera sombra (más moderno). -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Lista de Usuarios</h2>
        <a class="btn btn-success shadow-sm" href="create.php">
            + Crear Usuario
        </a>
    </div>

    <!-- Uso de Card
         Se encapsula la tabla en una card, shadow-lg: sombra elegante, border-0: elimina bordes feos, p-0: elimina padding innecesario. -->
    <div class="card shadow-lg border-0">
        <div class="card-body p-0">

        <!-- Tabla mejorada
             table-responsive: hace la tabla scrollable en pantallas pequeñas, table-hover: resalta -->
                <div class="table-responsive">
                <!-- Tabla mejorada con estilos modernos, align-middle: alinea contenido verticalmente, mb-0: elimina margen inferior.
                     Encabezado más visual, table-dark: fondo oscuro, text-center: centra texto. -->
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Usuario</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Web</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <?php if (isset($user['extension'])): ?>
                                        <!-- Mejora en imágenes de usuario: rounded-circle para hacerlas circulares, border para un borde sutil, object-fit: cover para que la imagen se ajuste sin distorsionarse. -->
                                        <img 
                                            src="<?php echo "users/images/${user['id']}.${user['extension']}" ?>" 
                                            class="rounded-circle border"
                                            style="width: 60px; height: 60px; object-fit: cover;"
                                        >
                                    <?php else: ?>
                                        <span class="text-muted">Sin imagen</span>
                                    <?php endif; ?>
                                </td>

                                <td class="fw-semibold"><?php echo $user['name'] ?></td>
                                <td><?php echo $user['username'] ?></td>
                                <td><?php echo $user['email'] ?></td>
                                <td><?php echo $user['phone'] ?></td>

                                <td>
                                    <a target="_blank" 
                                       class="text-decoration-none text-primary"
                                       href="http://<?php echo $user['website'] ?>">
                                        <?php echo $user['website'] ?>
                                    </a>
                                </td>

                                <td>
                                    <!-- Botones de acciones alineados verticalmente, con espacio entre ellos (gap-2), y confirmación al eliminar. -->
                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="view.php?id=<?php echo $user['id'] ?>" 
                                           class="btn btn-sm btn-info text-white">
                                            Ver
                                        </a>

                                        <a href="update.php?id=<?php echo $user['id'] ?>" 
                                           class="btn btn-sm btn-warning text-dark">
                                            Editar
                                        </a>

                                        <form method="POST" action="delete.php" 
                                              onsubmit="return confirm('¿Seguro que quieres eliminar este usuario?');">
                                            <input type="hidden" name="id" value="<?php echo $user['id'] ?>">
                                            <button class="btn btn-sm btn-danger">
                                                Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>
</div>

<?php include 'partials/footer.php' ?>