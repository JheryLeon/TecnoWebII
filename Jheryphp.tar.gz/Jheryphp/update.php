<?php
// -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15
require __DIR__ . '/users/users.php';

if (!isset($_GET['id'])) {
    include "partials/not_found.php";
    exit;
}
$userId = $_GET['id'];

$user = getUserById($userId);
if (!$user) {
    include "partials/not_found.php";
    exit;
}

// Inicializamos los errores como un array vacío o con valores nulos
$errors = [
    'name' => "",
    'username' => "",
    'email' => "",
    'phone' => "",
    'website' => "",
];

// Variable para rastrear si se intentó enviar el formulario
$isPost = false;
$isValid = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isPost = true; // Marcamos que hubo un intento de envío
    $user = array_merge($user, $_POST);

    $isValid = validateUser($user, $errors);

    if ($isValid) {
        $user = updateUser($_POST, $userId);

        if (isset($_FILES['picture']) && $_FILES['picture']['name']) {
            uploadImage($_FILES['picture'], $user);
        }

        header("Location: index.php");
        exit;
    }
}

include 'partials/header.php';
?>

<div class="container">
    <h1>Actualizar usuario: <b><?php echo htmlspecialchars($user['name']) ?></b></h1>

    <?php if ($isPost && !$isValid): ?>
        <div class="alert alert-danger">
            Por favor corrige los errores en el formulario.
        </div>
    <?php endif; ?>

    <?php include '_form.php'; ?>
</div>

<?php include 'partials/footer.php'; ?>