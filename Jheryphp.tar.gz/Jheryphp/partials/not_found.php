<?php // -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15 ?>
<div class="alert alert-danger">
    <h3>User does not exist</h3>
</div>
