<?php // -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15 ?>
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0">
                <?php if (isset($user['id']) && $user['id']): ?>
                    Actualizar Usuario: <b><?php echo htmlspecialchars($user['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></b>
                <?php else: ?>
                    Crear Nuevo Usuario
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body">

            <form method="POST" enctype="multipart/form-data" action="">
                
                <div class="form-group mb-3">
                    <label class="form-label">Nombre Completo</label>
                    <input name="name" 
                           value="<?php echo htmlspecialchars($user['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           class="form-control <?php echo isset($errors['name']) ? 'is-invalid' : ''; ?>"
                           placeholder="Ej. Juan Pérez">
                    <div class="invalid-feedback">
                        <?php echo $errors['name'] ?? ''; ?>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Nombre de Usuario (Username)</label>
                    <input name="username" 
                           value="<?php echo htmlspecialchars($user['username'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           class="form-control <?php echo isset($errors['username']) ? 'is-invalid' : ''; ?>"
                           placeholder="Ej. juanp88">
                    <div class="invalid-feedback">
                        <?php echo $errors['username'] ?? ''; ?>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Correo Electrónico</label>
                    <input type="email" name="email" 
                           value="<?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>"
                           placeholder="correo@ejemplo.com">
                    <div class="invalid-feedback">
                        <?php echo $errors['email'] ?? ''; ?>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Teléfono / Celular</label>
                    <input type="tel" name="phone" 
                           value="<?php echo htmlspecialchars($user['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           class="form-control <?php echo isset($errors['phone']) ? 'is-invalid' : ''; ?>"
                           placeholder="Ej. +54 11 1234 5678">
                    <div class="invalid-feedback">
                        <?php echo $errors['phone'] ?? ''; ?>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Sitio Web</label>
                    <input type="url" name="website" 
                           value="<?php echo htmlspecialchars($user['website'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           class="form-control <?php echo isset($errors['website']) ? 'is-invalid' : ''; ?>"
                           placeholder="https://tusitio.com">
                    <div class="invalid-feedback">
                        <?php echo $errors['website'] ?? ''; ?>
                    </div>
                </div>

                <div class="form-group mb-4">
                    <label class="form-label">Foto de Perfil</label>
                    
                    <?php if (isset($user['extension']) && $user['extension']): ?>
                        <div class="mb-2">
                            <img class="img-thumbnail" style="width: 80px; height: 80px; object-fit: cover;" 
                                 src="users/images/<?php echo $user['id'] . '.' . $user['extension']; ?>" 
                                 alt="Foto actual">
                            <p class="small text-muted">Imagen actual</p>
                        </div>
                    <?php endif; ?>

                    <input name="picture" type="file" class="form-control-file d-block" accept="image/*">
                    <small class="form-text text-muted">Formatos permitidos: JPG, PNG, GIF.</small>
                </div>

                <hr>

                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-success px-5">Guardar Cambios</button>
                </div>

            </form>
        </div>
    </div>
</div>