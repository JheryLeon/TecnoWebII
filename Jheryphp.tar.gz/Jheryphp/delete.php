<?php
// -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15
require __DIR__ . '/users/users.php';

// Verificar que se envió el ID
if (!isset($_POST['id'])) {
    include "partials/not_found.php";
    exit;
}

// Obtener ID y eliminar usuario
$userId = $_POST['id'];
deleteUser($userId);

// Redirigir al listado
header("Location: index.php");
exit; // importante detener el script después de redirigir