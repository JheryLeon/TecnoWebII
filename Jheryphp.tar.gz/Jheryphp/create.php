<?php
// -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15
require __DIR__ . '/users/users.php';

// Inicializar datos del usuario
$user = [
    'id' => '',
    'name' => '',
    'username' => '',
    'email' => '',
    'phone' => '',
    'website' => '',
];

// Inicializar errores
$errors = [
    'name' => "",
    'username' => "",
    'email' => "",
    'phone' => "",
    'website' => "",
];

$isValid = true;

// =======================
// 1️⃣ Procesar POST primero
// =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Actualizar datos del usuario con lo recibido del formulario
    $user = array_merge($user, $_POST);

    // Validar usuario (la función debe devolver true si es válido y actualizar $errors)
    $isValid = validateUser($user, $errors);

    if ($isValid) {
        // Crear usuario en la base de datos o archivo
        $user = createUser($_POST);

        // Subir imagen si existe
        if (isset($_FILES['picture'])) {
            uploadImage($_FILES['picture'], $user);
        }

        // Redirigir al listado de usuarios
        header("Location: index.php");
        exit; // Detener ejecución después de redirigir
    }
}

// =======================
// 2️⃣ Incluir header después de procesar POST
// =======================
include 'partials/header.php';
?>

<div class="container">
    <h1>Crear nuevo usuario</h1>

    <!-- Mostrar errores si los hay -->
    <?php if (!$isValid): ?>
        <div class="alert alert-danger">
            Por favor corrige los errores en el formulario.
        </div>
    <?php endif; ?>

    <!-- Formulario -->
    <?php include '_form.php'; ?>
</div>

<?php include 'partials/footer.php'; ?>