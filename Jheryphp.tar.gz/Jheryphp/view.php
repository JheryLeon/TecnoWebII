<?php
// -- nombre  : Johny Mauricio Mita Gutierrez -- Verificación del código 2026-03-15
include 'partials/header.php';
require __DIR__ . '/users/users.php';

if (!isset($_GET['id'])) {
    include "partials/not_found.php";
    exit;
}
$userId = $_GET['id'];

$user = getUserById($userId);
if (!$user) {
    include "partials/not_found.php";
    exit;
}

?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Ver usuario: <b><?php echo $user['name'] ?></b></h3>
        </div>
        <div class="card-body">
            <a class="btn btn-secondary" href="update.php?id=<?php echo $user['id'] ?>">Actualizar</a>
            <form style="display: inline-block" method="POST" action="delete.php">
                <input type="hidden" name="id" value="<?php echo $user['id'] ?>">
                <button class="btn btn-danger">Eliminar</button>
            </form>
        </div>
        <table class="table">
            <tbody>
            <tr>
                <th>Nombre:</th>
                <td><?php echo $user['name'] ?></td>
            </tr>
            <tr>
                <th>Usuario:</th>
                <td><?php echo $user['username'] ?></td>
            </tr>
            <tr>
                <th>Correo electrónico:</th>
                <td><?php echo $user['email'] ?></td>
            </tr>
            <tr>
                <th>Teléfono:</th>
                <td><?php echo $user['phone'] ?></td>
            </tr>
            <tr>
                <th>Sitio web:</th>
                <td>
                    <a target="_blank" href="http://<?php echo $user['website'] ?>">
                        <?php echo $user['website'] ?>
                    </a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'partials/footer.php' ?>